package com.hungta.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hungta.dao.OrderDao;
import com.hungta.entity.Order;
import com.hungta.service.OrderService;
import com.hungta.utils.UUIDUtil;

/**
 * @author HUNGTA on 01/08/18 - 10:35 PM
 * @project restfulmybatis
 */
@Service
@Transactional
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    public Order createOrder(Order order) {
        order.setOrderId(UUIDUtil.getUUID());
        if (!exists(order)){
            return null;
        }
        if (0 != orderDao.createOrder(order)) {
            return order;
        }
        return null;
    }

    public Boolean updateOrder(Order order) {
        return 0 != orderDao.updateOrder(order);
    }

    public Boolean deleteOrder(String orderId) {
        return 0 != orderDao.deleteOrder(orderId);
    }

    public Order findByOrderName(String orderName) {
        return orderDao.findByOrderName(orderName);
    }

    public Order findByOrderId(String orderId) {
        return orderDao.findByOrderId(orderId);
    }

    public List<Order> findAll() {
        return orderDao.findAll();
    }

    public boolean exists(Order order) {
        return orderDao.findByOrderName(order.getOrderName()) != null;
    }
}
