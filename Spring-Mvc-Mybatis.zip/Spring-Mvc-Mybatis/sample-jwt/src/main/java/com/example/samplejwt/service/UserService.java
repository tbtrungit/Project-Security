package com.example.samplejwt.service;


import com.example.samplejwt.entity.User;

import java.util.List;

public interface UserService {
    void resetCredentials();

    User findById(Long id);

    User findByUsername(String username);

    List<User> findAll();

}
