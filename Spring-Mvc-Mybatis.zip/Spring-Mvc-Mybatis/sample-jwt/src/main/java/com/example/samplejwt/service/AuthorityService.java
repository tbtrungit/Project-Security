package com.example.samplejwt.service;


import com.example.samplejwt.entity.Authority;

import java.util.List;

public interface AuthorityService {

    List<Authority> findById(Long id);

    List<Authority> findByname(String name);
}
